Simple text analyzer implemented in C. Provides functionality for spell checking and word occurances.    
Project for CSCI 2021 Spring 2025.